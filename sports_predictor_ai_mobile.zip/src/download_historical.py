from __future__ import annotations
import io
import os
from pathlib import Path
import requests
import pandas as pd
from .schema import normalize_matches

ROOT = Path(__file__).resolve().parents[1]
RAW = ROOT / "data" / "raw"
PROCESSED = ROOT / "data" / "processed"
RAW.mkdir(parents=True, exist_ok=True)
PROCESSED.mkdir(parents=True, exist_ok=True)
TIMEOUT = 45

def download(url: str, destination: Path) -> bytes:
    response = requests.get(url, timeout=TIMEOUT, headers={"User-Agent": "SportsPredictorStarter/1.0"})
    response.raise_for_status()
    destination.write_bytes(response.content)
    return response.content

def import_football_data():
    """Download selected historical Football-Data seasons for England Premier League.
    Review the source terms before using data for automated model training or commercial purposes.
    """
    all_rows = []
    # Common season naming convention, e.g. 2324.csv. This intentionally starts with recent seasons.
    for season in ["2021", "2122", "2223", "2324", "2425"]:
        url = f"https://www.football-data.co.uk/mmz4281/{season}/E0.csv"
        target = RAW / f"football_data_e0_{season}.csv"
        try:
            content = download(url, target)
            df = pd.read_csv(io.BytesIO(content), encoding="latin-1")
            if not {"Date", "HomeTeam", "AwayTeam", "FTHG", "FTAG"}.issubset(df.columns):
                print(f"Skip football season {season}: expected columns not found.")
                continue
            # Source dates often use DD/MM/YY; parse explicitly.
            normalized = pd.DataFrame({
                "date": pd.to_datetime(df["Date"], dayfirst=True, errors="coerce"),
                "competition": "English Premier League",
                "home_or_player_a": df["HomeTeam"],
                "away_or_player_b": df["AwayTeam"],
                "score_a": pd.to_numeric(df["FTHG"], errors="coerce"),
                "score_b": pd.to_numeric(df["FTAG"], errors="coerce"),
            })
            normalized["winner"] = ""
            normalized.loc[normalized["score_a"] > normalized["score_b"], "winner"] = normalized["home_or_player_a"]
            normalized.loc[normalized["score_b"] > normalized["score_a"], "winner"] = normalized["away_or_player_b"]
            normalized.loc[normalized["score_a"] == normalized["score_b"], "winner"] = "DRAW"
            normalized["date"] = normalized["date"].dt.strftime("%Y-%m-%d")
            normalized["source"] = "football-data.co.uk"
            # The common Elo backtest supports draws by skipping the winner-only target;
            # retain them in the normalized file for a future 1X2 goal model.
            normalized = normalized.dropna(subset=["date", "score_a", "score_b"])
            all_rows.append(normalized)
            print(f"Imported football season {season}: {len(normalized)} rows")
        except Exception as exc:
            print(f"Could not import football season {season}: {exc}")
    if all_rows:
        result = pd.concat(all_rows, ignore_index=True).sort_values("date")
        result.to_csv(PROCESSED / "football.csv", index=False)
        print(f"Wrote {len(result)} football rows to {PROCESSED / 'football.csv'}")
    else:
        print("No football data downloaded. Check internet access and source availability.")

def import_atp_tennis():
    """Download selected ATP historical match data from Jeff Sackmann's public repository."""
    all_rows = []
    for year in range(2018, 2026):
        url = f"https://raw.githubusercontent.com/JeffSackmann/tennis_atp/master/atp_matches_{year}.csv"
        target = RAW / f"atp_matches_{year}.csv"
        try:
            content = download(url, target)
            df = pd.read_csv(io.BytesIO(content), low_memory=False)
            needed = {"tourney_date", "winner_name", "loser_name"}
            if not needed.issubset(df.columns):
                print(f"Skip ATP {year}: expected columns not found.")
                continue
            date = pd.to_datetime(df["tourney_date"].astype("Int64").astype(str), format="%Y%m%d", errors="coerce")
            # IMPORTANT: orient players alphabetically, not winner-first, to prevent target leakage.
            # The winner remains a separate label and may be either participant.
            player_a = df[["winner_name", "loser_name"]].min(axis=1)
            player_b = df[["winner_name", "loser_name"]].max(axis=1)
            normalized = pd.DataFrame({
                "date": date.dt.strftime("%Y-%m-%d"),
                "competition": df["tourney_name"] if "tourney_name" in df else "",
                "home_or_player_a": player_a,
                "away_or_player_b": player_b,
                "score_a": float("nan"),
                "score_b": float("nan"),
                "winner": df["winner_name"],
                "source": "Jeff Sackmann tennis_atp",
                "surface": df["surface"] if "surface" in df else "",
                "best_of": df["best_of"] if "best_of" in df else float("nan"),
            })
            normalized = normalized.dropna(subset=["date", "home_or_player_a", "away_or_player_b", "winner"])
            all_rows.append(normalized)
            print(f"Imported ATP {year}: {len(normalized)} rows")
        except Exception as exc:
            print(f"Could not import ATP {year}: {exc}")
    if all_rows:
        result = pd.concat(all_rows, ignore_index=True).sort_values("date")
        result.to_csv(PROCESSED / "tennis_atp.csv", index=False)
        print(f"Wrote {len(result)} ATP rows to {PROCESSED / 'tennis_atp.csv'}")
    else:
        print("No ATP data downloaded. Check internet access and source availability.")

if __name__ == "__main__":
    import_football_data()
    import_atp_tennis()
