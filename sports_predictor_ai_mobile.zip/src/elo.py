from __future__ import annotations
from dataclasses import dataclass, field
from math import log
from typing import Dict, Tuple

@dataclass
class EloModel:
    k_factor: float = 24.0
    initial_rating: float = 1500.0
    home_advantage: float = 55.0
    ratings: Dict[str, float] = field(default_factory=dict)

    def rating(self, name: str) -> float:
        return self.ratings.get(str(name), self.initial_rating)

    def probability_a(self, a: str, b: str, home_advantage: float = 0.0) -> float:
        ra = self.rating(a) + home_advantage
        rb = self.rating(b)
        return 1.0 / (1.0 + 10.0 ** ((rb - ra) / 400.0))

    def update(self, a: str, b: str, winner: str, home_advantage: float = 0.0) -> None:
        """Update after the result is known. Winner must equal a or b; draws are skipped."""
        if winner not in (a, b):
            return
        pa = self.probability_a(a, b, home_advantage)
        actual_a = 1.0 if winner == a else 0.0
        # Update base ratings; home advantage is contextual, not permanently added to a team's rating.
        ra, rb = self.rating(a), self.rating(b)
        self.ratings[str(a)] = ra + self.k_factor * (actual_a - pa)
        self.ratings[str(b)] = rb + self.k_factor * ((1.0 - actual_a) - (1.0 - pa))

def binary_metrics(probabilities, labels):
    """Brier and log loss for binary outcomes, with numerical clipping."""
    import numpy as np
    p = np.clip(np.asarray(probabilities, dtype=float), 1e-8, 1 - 1e-8)
    y = np.asarray(labels, dtype=float)
    brier = float(((p - y) ** 2).mean()) if len(y) else float("nan")
    logloss = float((-(y * np.log(p) + (1-y) * np.log(1-p))).mean()) if len(y) else float("nan")
    return brier, logloss
