from __future__ import annotations
import pandas as pd

REQUIRED_COLUMNS = [
    "date", "sport", "competition", "home_or_player_a",
    "away_or_player_b", "score_a", "score_b", "winner", "source"
]

def normalize_matches(df: pd.DataFrame, sport: str, source: str) -> pd.DataFrame:
    """Normalize rows to the project's shared schema without inventing missing results."""
    out = pd.DataFrame()
    out["date"] = pd.to_datetime(df.get("date"), errors="coerce").dt.strftime("%Y-%m-%d")
    out["sport"] = sport
    out["competition"] = df["competition"] if "competition" in df else ""
    out["home_or_player_a"] = df["home_or_player_a"] if "home_or_player_a" in df else df.get("player_a", "")
    out["away_or_player_b"] = df["away_or_player_b"] if "away_or_player_b" in df else df.get("player_b", "")
    out["score_a"] = pd.to_numeric(df["score_a"], errors="coerce") if "score_a" in df else float("nan")
    out["score_b"] = pd.to_numeric(df["score_b"], errors="coerce") if "score_b" in df else float("nan")
    if "winner" in df:
        out["winner"] = df["winner"]
    else:
        a_wins = out["score_a"] > out["score_b"]
        b_wins = out["score_b"] > out["score_a"]
        out["winner"] = ""
        out.loc[a_wins, "winner"] = out.loc[a_wins, "home_or_player_a"]
        out.loc[b_wins, "winner"] = out.loc[b_wins, "away_or_player_b"]
    out["source"] = source
    out["surface"] = df["surface"] if "surface" in df else ""
    out["best_of"] = df["best_of"] if "best_of" in df else float("nan")
    out = out.dropna(subset=["date"])
    out["winner"] = out["winner"].fillna("").astype(str)
    out["home_or_player_a"] = out["home_or_player_a"].fillna("").astype(str)
    out["away_or_player_b"] = out["away_or_player_b"].fillna("").astype(str)
    out = out[
        (out["home_or_player_a"] != "") &
        (out["away_or_player_b"] != "") &
        (out["winner"] != "")
    ]
    return out[REQUIRED_COLUMNS + ["surface", "best_of"]].sort_values("date").reset_index(drop=True)
