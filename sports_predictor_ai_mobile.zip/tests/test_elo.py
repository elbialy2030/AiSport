import unittest
from src.elo import EloModel, binary_metrics

class TestElo(unittest.TestCase):
    def test_equal_ratings_equal_probability(self):
        model = EloModel()
        self.assertAlmostEqual(model.probability_a("A", "B"), 0.5, places=6)

    def test_winner_rating_increases(self):
        model = EloModel()
        before = model.rating("A")
        model.update("A", "B", "A")
        self.assertGreater(model.rating("A"), before)

    def test_draw_is_not_updated(self):
        model = EloModel()
        before_a, before_b = model.rating("A"), model.rating("B")
        model.update("A", "B", "DRAW")
        self.assertEqual(model.rating("A"), before_a)
        self.assertEqual(model.rating("B"), before_b)

    def test_metrics_are_finite(self):
        brier, logloss = binary_metrics([0.8, 0.2], [1, 0])
        self.assertTrue(0 <= brier <= 1)
        self.assertGreaterEqual(logloss, 0)

if __name__ == "__main__":
    unittest.main()
