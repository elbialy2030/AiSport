from pathlib import Path
import pandas as pd
import streamlit as st

ROOT = Path(__file__).resolve().parent
DATA = ROOT / "data" / "processed"
REPORTS = ROOT / "reports"

st.set_page_config(page_title="Sports Predictor AI", page_icon="🏟️", layout="wide")
st.title("🏟️ Sports Predictor AI — Mobile Edition")
st.caption("Historical baseline and data-readiness dashboard. Probabilities are not guaranteed outcomes.")

st.warning(
    "Starter version: football and ATP tennis historical importers are included. "
    "Basketball and volleyball require an additional reliable data adapter. "
    "The app does not invent fixtures or claim a model has been validated."
)

tabs = st.tabs(["Overview", "Historical data", "Backtest report", "Daily report"])
with tabs[0]:
    st.subheader("Project status")
    sport_files = {
        "Football": DATA / "football.csv",
        "Tennis (ATP)": DATA / "tennis_atp.csv",
        "Basketball": DATA / "basketball.csv",
        "Volleyball": DATA / "volleyball.csv",
    }
    cols = st.columns(2)
    for i, (sport, path) in enumerate(sport_files.items()):
        with cols[i % 2]:
            if path.exists():
                try:
                    df = pd.read_csv(path)
                    st.metric(sport, f"{len(df):,} rows")
                    if "date" in df and len(df):
                        st.caption(f"Date range: {df['date'].min()} to {df['date'].max()}")
                except Exception:
                    st.metric(sport, "File error")
            else:
                st.metric(sport, "No data yet")
    st.info("Run `python -m src.download_historical` in the cloud terminal to attempt public historical imports.")

with tabs[1]:
    st.subheader("Historical data preview")
    for sport, filename in [("Football", "football.csv"), ("Tennis ATP", "tennis_atp.csv"),
                            ("Basketball", "basketball.csv"), ("Volleyball", "volleyball.csv")]:
        path = DATA / filename
        with st.expander(sport):
            if path.exists():
                try:
                    st.dataframe(pd.read_csv(path).head(100), use_container_width=True)
                except Exception as exc:
                    st.error(f"Could not read file: {exc}")
            else:
                st.write("No dataset imported yet.")

with tabs[2]:
    st.subheader("Chronological backtest")
    report = REPORTS / "backtest_report.md"
    if report.exists():
        st.markdown(report.read_text(encoding="utf-8"))
    else:
        st.write("No report yet. Run `python -m src.backtest` after importing historical data.")

with tabs[3]:
    st.subheader("Daily report")
    report = REPORTS / "daily_report.md"
    if report.exists():
        st.markdown(report.read_text(encoding="utf-8"))
    else:
        st.write("No daily report generated yet. Run `python -m src.daily_report`.")
