# Sports Predictor AI — Mobile Edition

Starter project for a multi-sport prediction system, designed to be managed from a phone browser.

## What this version does

- Supports a common match-data schema for football, tennis, basketball, and volleyball.
- Downloads public historical match CSVs for football (Football-Data) and men's ATP tennis (Jeff Sackmann repository).
- Builds an Elo baseline using only matches that occurred before each prediction.
- Runs chronological walk-forward backtests and reports accuracy, Brier score, and log loss.
- Provides a Streamlit dashboard for data status and historical evaluation.
- Includes a GitHub Actions workflow template for a daily report run.

## Important limitations

- This is a starter baseline, not a proven profitable prediction system.
- The historical importers cover football and ATP tennis only. Basketball and volleyball need a licensed/reliable data source and an adapter; the schema and model interface are ready for them, but this project does not fabricate their historical records.
- Football-Data and other source terms may restrict commercial use or automated model training. Review each source's terms before use.
- Football-Data columns vary by season/league. The importer normalizes common columns and skips rows it cannot parse.
- Tennis files are large and may take time to download on a phone-based cloud workspace.
- The ATP importer orders the two player names alphabetically, rather than putting the winner first, to avoid target leakage in the winner-prediction task.
- No data is bundled as if it had been downloaded or tested. You must run the import step in the cloud workspace.

## Run it from a phone

1. Create a GitHub account if you do not already have one.
2. Create a new **public or private repository** and upload the files from this ZIP (GitHub mobile website supports uploading files, though uploading a ZIP as a repository does not unpack it automatically).
   - Easiest: open GitHub in your phone browser, create a repository, then use **Add file → Upload files** to upload the extracted project files. If your phone cannot extract ZIP files, use a cloud IDE that can import a ZIP or upload files individually.
3. Open the repository on GitHub and choose **Code → Codespaces → Create codespace on main** (availability and free quota depend on your account).
4. In the Codespaces terminal, run:
   ```bash
   pip install -r requirements.txt
   python -m src.download_historical
   python -m src.backtest
   streamlit run app.py --server.address 0.0.0.0 --server.port 8501
   ```
5. Open the forwarded port 8501 in the Codespaces Ports panel.

## Data files

The importer writes normalized files to `data/processed/`:
- `football.csv`
- `tennis_atp.csv`

Raw source downloads go to `data/raw/`.

The standard schema for any sport is:
`date, sport, competition, home_or_player_a, away_or_player_b, score_a, score_b, winner, surface, best_of, source`

- `date`: ISO date (YYYY-MM-DD)
- `sport`: football, tennis, basketball, volleyball
- `competition`: league/tournament
- `home_or_player_a`, `away_or_player_b`: team/player names
- `score_a`, `score_b`: numeric score fields when meaningful
- `winner`: exact name matching one of the two participants
- `surface`, `best_of`: optional tennis fields
- `source`: dataset provenance

## Chronological evaluation

`python -m src.backtest` evaluates later matches in date order. Elo ratings are updated only after a match's result is known. All matches on the same calendar date are predicted before any result from that date updates ratings, because exact kickoff times may be unavailable. It does not randomly split rows, and it does not use future match outcomes to rate an earlier match.

Metrics:
- Accuracy: fraction of evaluated matches where the most likely winner was correct.
- Brier score: mean squared error for the two-outcome probability vector.
- Log loss: penalizes confident wrong predictions.

These metrics do not prove future performance. Compare the model with a simple baseline and keep a final untouched time period for one-time evaluation.

## Daily report

The workflow in `.github/workflows/daily-report.yml` is a template. To enable it:
1. Add repository Actions permissions if needed.
2. Set the workflow schedule to your preferred UTC time.
3. The scheduled run imports data and generates `reports/daily_report.md`.
4. GitHub Actions logs show the output. This template does not automatically message you on WhatsApp or Telegram.

**Fixture warning:** the initial version does not have a universal free, reliable live fixture feed across all four sports. Daily match predictions are only produced after you add an upcoming-fixtures file from a source you are permitted to use. No fixture or prediction is invented.

## Next implementation milestones

1. Add official/licensed upcoming fixtures and team/player availability feeds.
2. Add sport-specific models:
   - Football: Poisson/Dixon-Coles goals + Elo.
   - Tennis: surface-adjusted Elo and serve/return features.
   - Basketball: team efficiency, pace, rest, and injury availability.
   - Volleyball: set/point-level team strength and serve/receive stats.
3. Compare calibrated model probabilities with market-implied probabilities only if permitted odds data is available.
4. Track every prediction timestamp and outcome; never overwrite losing predictions.
